# wpinventory
WP Inventory Manager core plugin repository.
