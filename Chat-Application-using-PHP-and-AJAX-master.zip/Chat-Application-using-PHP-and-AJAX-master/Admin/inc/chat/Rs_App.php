<?php
/**
 * 
 */
class Rs_App
{
	public $baseUrl;
	function __construct()
	{
		$this->baseUrl = "http://localhost/EasyTure2/";
	}
	public function CheckString($string){
		return $string;
	}
}