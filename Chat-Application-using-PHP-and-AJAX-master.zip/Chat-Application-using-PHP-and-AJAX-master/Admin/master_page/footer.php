<footer class="footer footer-light" style="position: fixed;left: 0;bottom: 0;width: 100%;">
    <p class="clearfix text-muted text-sm-center mb-0 px-2" ><span class="float-md-left d-xs-block d-md-inline-block" >Copyright  &copy; 2017 , All rights reserved. </span><span class="float-md-right d-xs-block d-md-inline-block"><b>Md Rukon Shekh</b> </span></p>
</footer>