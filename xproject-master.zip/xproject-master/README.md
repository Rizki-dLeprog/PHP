xproject
========

Ini adalah direktori pengembangan sistem informasi untuk monitoring program mentoring agama islam di SMA, sekaligus sistem manajemen organisasi alumni rohis SMA. Bagi yang ingin berkontribusi dalam bentuk apapun, silakan hubungi admin di andika dot csui ad gmail dot com. Terima kasih banyak :)
