<?php
$us = ""; // $user;
function content($data) {
    ?>
    <div>
        <table>
            <?php foreach ($data as $k => $v) { ?>
                <tr><td><?php echo $k; ?></td><td><?php echo $v; ?></td></tr>
            <?php } ?>
        </table>
    </div>
    <?php
}
$title = "Lihat Profil";
require_once APPPATH . 'views/layout_normal.php';
?>
