<ul>
    <li>Menu mentor 1</li>
    <li>Menu mentor 2</li>
</ul>