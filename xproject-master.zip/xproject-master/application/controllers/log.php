<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class pengumuman extends CI_Controller {

    /**
     * Membuka halaman buat pengumuman
     */
    public function buat() {
        
    }
    
    /**
     * Menyimpan pengumuman yang dibuat
     */
    public function  buat_post(){
        
    }
    
    /**
     * Lihat pengumuman untuk mentor tertentu
     */
    public function lihat($mentor){
        
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */