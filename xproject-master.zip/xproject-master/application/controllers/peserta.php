<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class peserta extends CI_Controller {
    
    /**
     * Membuka halaman daftar mentor
     */
    public function mentor(){
        
    }
    
    /**
     * Melihat daftar mentee pada kelas tertentu
     * @param type $kelas
     */
    public function mentee($kelas){
        
    }
    
    /**
     * Mengirimkan seluruh daftar user dan binaannya ke email admin
     */
    public function unduh(){
        
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */