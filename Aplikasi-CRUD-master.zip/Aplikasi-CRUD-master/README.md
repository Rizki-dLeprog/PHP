# Aplikasi-CRUD
Aplikasi CRUD di buat dengan CodeIgniter 3 dan php v7. di buat dari hasil belajar dengan YT channel : Web Programming Unpas
