<div class="container">
	<!-- card -->
	  <div class="row section" style="margin-top: 100px;">
	    <div class="col s12">
	      <div class="card cyan darken-2">
	        <div class="card-content white-text">
	          <span class="card-title">Hello !</span>
	          <p>Selamat datang di aplikasi CRUD Data mahasiswa buatan saya. untuk lebih mengenal saya, silahka follow akun sosial media saya di bawah ini. <br>
	          have a nice day !!!</p>
	        </div>
	        <div class="card-action center">
	          <a href="#"><span class="fa fa-instagram fa-3x"></span> </a>
	          <a href="#"><span class="fa fa-facebook fa-3x"></span></a>
	        </div>
	      </div>
	    </div>
	  </div>
            
</div>