<?php

    $base_url = "http://localhost.yii/simple-kasir/" ;

?>