				
	<div class="row-fluid">
			<div class="span12"></div>
				  <div class="row-fluid">
						<div class="span10">
						<img class="index_logo" src="admin/images/sclogo.png">
						</div>	
						<div class="span12">
							<div class="motto">
							<p>WELCOME&nbsp;&nbsp;TO:</p>
							<p>Technology Resource Inventory System&nbsp;(TRIS)</p>												
							</div>											
						</div>							
				  </div>		   							
    </div>	
				